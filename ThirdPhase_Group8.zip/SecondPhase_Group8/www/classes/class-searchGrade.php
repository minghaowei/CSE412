<?php

class search{

	private $mysqli;

	public function __construct(){
		$this->connect();
	}

	private function connect(){
		$this->mysqli = new mysqli('localhost', 'root', 'A159654a', 'phase2');
	}

	public function search($search_term){
		$sanitized = $this->mysqli->real_escape_string($search_term);

		$query = $this->mysqli->query("
				select t.sid, s.name, c.cname, count(*) * 10 as grade
				from test t, course c, questions q, student s
				where t.cid = c.cid
					and t.qid = q.id
					and c.cname = q.cname
    				and t.answer = q.answer
    				and t.sid = s.id
    				and s.id = '$search_term'
				group by t.sid, t.cid
				order by t.sid, t.cid
		");

		if ( ! $query->num_rows){
			return false;
		}
		while($row = mysqli_fetch_array($query)){
			$sid = $row['sid'];
			$name = $row['name'];
			$cname = $row['cname'];
			$grade = $row['grade'];

			echo $sid . ': ' . $name . ": " . $cname . ': ' . $grade . ': '. '<br />';
		}
		/*while( $row = $query->fetch_object()){
			$row[] = $row;
		}

		$search_results = array(
			'count' => $query->num_rows,
			'results' => $row,
		);
		return $search_results;*/
	}
}







?>