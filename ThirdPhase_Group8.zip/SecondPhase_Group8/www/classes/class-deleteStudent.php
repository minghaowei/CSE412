<?php

class search{

	private $mysqli;

	public function __construct(){
		$this->connect();
	}

	private function connect(){
		$this->mysqli = new mysqli('localhost', 'root', 'A159654a', 'phase2');
	}

	public function search($search_term){
		$sanitized = $this->mysqli->real_escape_string($search_term);

		$query = $this->mysqli->query("
				SET SQL_SAFE_UPDATES = 0;
				delete from student where name = $search_term;
				SET SQL_SAFE_UPDATES = 1;
		");
		echo $search_term . ' deleted' . '<br />';

		/*while( $row = $query->fetch_object()){
			$row[] = $row;
		}

		$search_results = array(
			'count' => $query->num_rows,
			'results' => $row,
		);
		return $search_results;*/
	}
}







?>