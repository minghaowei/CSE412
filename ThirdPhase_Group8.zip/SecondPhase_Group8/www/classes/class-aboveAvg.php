<?php

class search{

	private $mysqli;

	public function __construct(){
		$this->connect();
	}

	private function connect(){
		$this->mysqli = new mysqli('localhost', 'root', 'A159654a', 'phase2');
	}

	public function search($search_term){
		$sanitized = $this->mysqli->real_escape_string($search_term);

		$query = $this->mysqli->query("
				select s.name, t.cid, c.cname, count(*) * 10 as grade
				from test t, course c, questions q, student s
				where t.cid = c.cid
				and t.qid = q.id
				and c.cname = q.cname
				and t.answer = q.answer
				and t.sid = s.id
				and c.cid = '$search_term'
				group by t.sid, t.cid
                having count(*) > (
                select avg(grade)
				from (
				select t.sid, s.name, t.cid, c.cname, count(*) as grade
				from test t, course c, questions q, student s
				where t.cid = c.cid
				and t.qid = q.id
				and c.cname = q.cname
    			and t.answer = q.answer
    			and t.sid = s.id
    			and c.cid = '$search_term'
				group by t.sid, t.cid
				order by t.sid, t.cid
				) as t
                );
		");

		if ( ! $query->num_rows){
			return false;
		}
		while($row = mysqli_fetch_array($query)){
			$name = $row['name'];
			$cid = $row['cid'];
			$cname = $row['cname'];
			$grade = $row['grade'];

			echo $name . ' : ' . $cid . ' : ' . $cname . ' : ' . $grade . '<br />';
		}
		/*while( $row = $query->fetch_object()){
			$row[] = $row;
		}

		$search_results = array(
			'count' => $query->num_rows,
			'results' => $row,
		);
		return $search_results;*/
	}
}







?>