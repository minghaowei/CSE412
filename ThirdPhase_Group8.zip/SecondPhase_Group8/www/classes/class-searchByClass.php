<?php

class search{

	private $mysqli;

	public function __construct(){
		$this->connect();
	}

	private function connect(){
		$this->mysqli = new mysqli('localhost', 'root', 'A159654a', 'phase2');
	}

	public function search($search_term){
		$sanitized = $this->mysqli->real_escape_string($search_term);

		$query = $this->mysqli->query("
				select s.name, c.cname
				from student s, take tk, course c
				where s.id = tk.sid
				and c.cid = tk.cid
    			and c.cid = '$search_term'
				order by c.cid
		");

		if ( ! $query->num_rows){
			return false;
		}
		while($row = mysqli_fetch_array($query)){
			$name = $row['name'];
			$cname = $row['cname'];

			echo $name . ': ' . $cname . ": " . '<br />';
		}
		/*while( $row = $query->fetch_object()){
			$row[] = $row;
		}

		$search_results = array(
			'count' => $query->num_rows,
			'results' => $row,
		);
		return $search_results;*/
	}
}







?>