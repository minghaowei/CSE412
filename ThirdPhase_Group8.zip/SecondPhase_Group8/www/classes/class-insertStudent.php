<?php

class search{

	private $mysqli;

	public function __construct(){
		$this->connect();
	}

	private function connect(){
		$this->mysqli = new mysqli('localhost', 'root', 'A159654a', 'phase2');
	}

	public function search($search_term){
		$sanitized = $this->mysqli->real_escape_string($search_term);

		$query = $this->mysqli->query("
				insert into student (id, name, identity) value ((select count(*) as total from student as s) + 1, '$search_term', 1)
		");
		echo $search_term . ' insert successfully' . '<br />';

		/*while( $row = $query->fetch_object()){
			$row[] = $row;
		}

		$search_results = array(
			'count' => $query->num_rows,
			'results' => $row,
		);
		return $search_results;*/
	}
}







?>