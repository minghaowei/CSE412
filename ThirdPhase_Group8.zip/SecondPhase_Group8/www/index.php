<html>
	<head>
		<title>Home</title>
	</head>
	<body>
		<h1>Select functions</h1>
		<a href="http://127.0.0.1/searchByClass" taget="_blank">Search student in a class</a>
		<br>
		<a href="http://127.0.0.1/searchPassing" taget="_blank">Search student who pass a class</a>
		<br>
		<a href="http://127.0.0.1/searchAvg" taget="_blank">Search average in a class</a>
		<br>
		<a href="http://127.0.0.1/searchGrade" taget="_blank">Search student's grade</a>
		<br>
		<a href="http://127.0.0.1/aboveAvg" taget="_blank">Student above average</a>
		<br>
		<a href="http://127.0.0.1/insertStudent" taget="_blank">Insert a student</a>
		<br>
		<a href="http://127.0.0.1/deleteStudent" taget="_blank">Delect a student</a>
		<br>
	</body>



</html>