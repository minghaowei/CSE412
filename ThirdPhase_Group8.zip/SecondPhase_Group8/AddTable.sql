CREATE TABLE course (
	cid CHAR(11),
	cname CHAR(50),
	semester VARCHAR(20),
	PRIMARY KEY (cid)
);

CREATE TABLE CourseIndex
ON course(cid);

-- identity 1 means student, 2 means teacher
CREATE TABLE teacher (
	id CHAR(11),
	name CHAR(50),
	identity INTEGER DEFAULT 2,
	PRIMARY KEY (id)
);


CREATE TABLE student (
	id CHAR(11),
	name CHAR(50),
	identity INTEGER DEFAULT 1,
	PRIMARY KEY (id)
);

CREATE INDEX StudentIndex
ON student(id);

CREATE TABLE teach (
	tid CHAR(11),
	cid CHAR(11),
	PRIMARY KEY (tid, cid),
	FOREIGN KEY (tid) REFERENCES teacher(id)
	ON DELETE NO ACTION,
	FOREIGN KEY (cid) REFERENCES course(cid)
	ON DELETE NO ACTION
);

CREATE TABLE take (
	sid CHAR(11),
	cid CHAR(11),
	PRIMARY KEY (sid, cid),
	FOREIGN KEY (sid) REFERENCES student(id)
	ON DELETE CASCADE,
	FOREIGN KEY (cid) REFERENCES course(cid)
	ON DELETE NO ACTION
);

CREATE TABLE question (
	cname CHAR(50),
	id INTEGER,
	CHECK(id > 0),
	content TEXT,
	answer TEXT,
	PRIMARY KEY (cname, id)
);

CREATE TABLE has_testPaper (
	cid CHAR(11),
	tpid INTEGER,
	start_time DATETIME,
	end_time DATETIME,
	PRIMARY KEY (cid, tpid),
	FOREIGN KEY (cid) REFERENCES course(cid)
	ON DELETE CASCADE
);

DELIMITER //
CREATE PROCEDURE check_time (IN start_time DATETIME, IN end_time DATETIME)
BEGIN
IF end_time < start_time THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'check constraint on has_testPaper.start_time & has_testPaper.end_time failed.';
END IF;
END //

CREATE TRIGGER tri_time_insert BEFORE INSERT ON has_testPaper
FOR EACH ROW
BEGIN
CALL check_time(new.start_time, new.end_time);
END //

CREATE TRIGGER tri_time_update BEFORE UPDATE ON has_testPaper
FOR EACH ROW
BEGIN
CALL check_time(new.start_time, new.end_time);
END //
DELIMITER ;

-- student take test paper

-- testpaper generate form question
CREATE TABLE generate (
	cname CHAR(50),
	tpid INTEGER,
	qid INTEGER,
	PRIMARY KEY (cname, tpid, qid),
	FOREIGN KEY (cname, qid) REFERENCES question(cname, id)
	ON DELETE CASCADE
);

CREATE TABLE test (
	sid CHAR(11),
	CHECK(sid <> ''),
	cname CHAR(50),
	cid CHAR(11),
	tpid INTEGER,
	qid INTEGER,
	answer TEXT,
	PRIMARY KEY (sid, cid, cname, tpid, qid),
	FOREIGN KEY (sid) REFERENCES student(id)
	ON DELETE CASCADE,
	FOREIGN KEY (cname, qid) REFERENCES generate(cname, qid)
	ON DELETE NO ACTION, 
	FOREIGN KEY (cid, tpid) REFERENCES has_testPaper(cid, tpid)
	ON DELETE NO ACTION
);

DELIMITER //
CREATE TRIGGER tri_cn_update AFTER UPDATE ON course
FOR EACH ROW 
BEGIN
if new.cname != old.cname then
update question set question.cname = new.cname where question.cname = old.cname;
update test set test.cname = new.cname where test.cname = old.cname;
end if;
end //


CREATE PROCEDURE ERROR_INFO ()
BEGIN
IF TRUE THEN
SIGNAL SQLSTATE '45001'
SET MESSAGE_TEXT = 'check constraint on teacher.id & student.id failed. Teacher and Student can\'t have the same id.';
END IF;
END//

-- CHECK CONSTRAINT that teacher's identity must be 2
-- CHECK CONSTRAINT that teacher can not have the same id as student's
CREATE TRIGGER tri_id1 BEFORE INSERT ON teacher
FOR EACH ROW
BEGIN
IF new.identity != 2 THEN UPDATE teacher SET new.identity = 2;
END IF;
IF (new.id IN (SELECT s.id from student s))
THEN
CALL ERROR_INFO();
END IF;
END //

-- CHECK CONSTRAINT that student's identity must be 1
CREATE TRIGGER tri_id2 BEFORE INSERT ON student
FOR EACH ROW
BEGIN
IF new.identity != 1 THEN UPDATE student SET new.identity = 1;
END IF;
IF (new.id IN (SELECT t.id from teacher t))
THEN
CALL ERROR_INFO();
END IF;
END //
DELIMITER ;




