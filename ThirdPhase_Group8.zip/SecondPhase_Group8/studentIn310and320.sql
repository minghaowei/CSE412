select id, name
from student
where id in (
	select s.id
    from student s, take tk, course c
    where s.id = tk.sid
		and tk.cid = c.cid
        and c.cname = 'cse310'
	)
    and id in (
    select s.id
    from student s, take tk, course c
    where s.id = tk.sid
		and tk.cid = c.cid
        and c.cname = 'cse320'
	)
	