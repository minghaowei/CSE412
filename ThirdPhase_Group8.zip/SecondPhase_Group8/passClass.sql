select s.name, t.cid, count(*) * 10 as grade
from test t, course c, questions q, student s
where t.cid = c.cid
	and t.qid = q.id
	and c.cname = q.cname
    and t.answer = q.answer
    and t.sid = s.id
    and t.cid = 102
group by t.sid, t.cid
having count(*) > 4
order by t.sid