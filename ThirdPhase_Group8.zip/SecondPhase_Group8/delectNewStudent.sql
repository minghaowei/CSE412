SET SQL_SAFE_UPDATES = 0;
delete from student where id = 151;
SET SQL_SAFE_UPDATES = 1;