 SET FOREIGN_KEY_CHECKS = 0;
 
 load data local infile 'course.csv' 
 into table course
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
 (cid, cname, semester);

 load data local infile 'teacher.csv' 
 into table teacher
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
 (id, name, identity);

load data local infile 'student.csv' 
 into table student
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
 (id, name, identity);

 load data local infile 'teach.csv' 
 into table teach
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines;

 load data local infile 'questions.csv' 
 into table question
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines;

 load data local infile 'take.csv' 
 into table take
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines;

 load data local infile 'has_testPaper.txt' 
 into table has_testpaper
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines;

 load data local infile 'generate.csv' 
 into table generate
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines;

 load data local infile 'test.csv' 
 into table test
 fields terminated by ','
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines;



