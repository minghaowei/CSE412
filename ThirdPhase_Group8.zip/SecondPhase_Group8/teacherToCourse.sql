select t.name, c.cid, c.cname
from teacher t, teach te, course c
where t.id = te.tid
	and te.cid = c.cid