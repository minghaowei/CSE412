select c.cname, ht.tpid, ht.start_time, ht.end_time
from course c, has_testpaper ht
where c.cid = ht.cid
	and c.cid = 101