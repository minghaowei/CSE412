select s.name, c.cname
from student s, take tk, course c
where s.id = tk.sid
	and c.cid = tk.cid
    and c.cid = 101
order by c.cid