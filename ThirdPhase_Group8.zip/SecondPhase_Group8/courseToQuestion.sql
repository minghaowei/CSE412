select c.cid, t.tpid, c.cname, q.id, q.answer, q.content
from course c, question q, generate g, has_testpaper t
where c.cid = t.cid
	and t.tpid = g.tpid
    and g.cname = c.cname
    and g.cname = q.cname
    and g.qid = q.id
    and c.cid = 101
order by c.cid
